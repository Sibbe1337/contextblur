/**
 * ContextBlur - Side Panel Controller
 * Manages UI state and communication with content scripts
 */

(() => {
  'use strict';

  // DOM Elements
  const elements = {
    blurModeToggle: document.getElementById('blurModeToggle'),
    modeStatus: document.getElementById('modeStatus'),
    activeIndicator: document.getElementById('activeIndicator'),
    blurCount: document.getElementById('blurCount'),
    clearAllBtn: document.getElementById('clearAllBtn'),
    confirmClearBtn: document.getElementById('confirmClearBtn'),
    emptyState: document.getElementById('emptyState'),
    hasBlursState: document.getElementById('hasBlursState'),
    // Auto-blur elements
    runAutoBlurBtn: document.getElementById('runAutoBlurBtn'),
    autoBlurResult: document.getElementById('autoBlurResult'),
    blurEmails: document.getElementById('blurEmails'),
    blurPhones: document.getElementById('blurPhones'),
    blurCards: document.getElementById('blurCards'),
    blurSSN: document.getElementById('blurSSN'),
    // Modal elements
    disclosureModal: document.getElementById('disclosureModal'),
    modalCancelBtn: document.getElementById('modalCancelBtn'),
    modalAcceptBtn: document.getElementById('modalAcceptBtn')
  };

  // State
  let currentTabId = null;
  let currentUrl = null;
  let confirmTimeout = null;
  let disclosureAccepted = false;
  let pendingAutoBlurRun = false;

  // Initialize
  init();

  async function init() {
    await getCurrentTab();
    await loadState();
    await checkDisclosureStatus();
    setupEventListeners();
    startPolling();
  }

  async function getCurrentTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      currentTabId = tab.id;
      currentUrl = tab.url;
    }
  }

  async function checkDisclosureStatus() {
    try {
      const result = await chrome.storage.local.get('autoBlurDisclosureAccepted');
      disclosureAccepted = result.autoBlurDisclosureAccepted === true;
    } catch (e) {
      disclosureAccepted = false;
    }
  }

  async function loadState() {
    if (!currentTabId) return;

    try {
      const state = await chrome.runtime.sendMessage({
        type: 'GET_STATE',
        tabId: currentTabId
      });

      if (state) {
        elements.blurModeToggle.checked = state.blurModeEnabled;
        updateToggleUI(state.blurModeEnabled);
      }

      await updateBlurCount();
    } catch (e) {
      console.error('Failed to load state:', e);
    }
  }

  function setupEventListeners() {
    // Blur mode toggle
    elements.blurModeToggle.addEventListener('change', handleToggleChange);

    // Clear all button
    elements.clearAllBtn.addEventListener('click', handleClearClick);
    elements.confirmClearBtn.addEventListener('click', handleConfirmClear);

    // Auto-blur run button
    elements.runAutoBlurBtn.addEventListener('click', handleRunAutoBlur);

    // Modal buttons
    elements.modalCancelBtn.addEventListener('click', handleModalCancel);
    elements.modalAcceptBtn.addEventListener('click', handleModalAccept);

    // Close modal on overlay click
    elements.disclosureModal.addEventListener('click', (e) => {
      if (e.target === elements.disclosureModal) {
        handleModalCancel();
      }
    });

    // Listen for tab changes
    chrome.tabs.onActivated.addListener(handleTabChange);
    chrome.tabs.onUpdated.addListener(handleTabUpdate);

    // Listen for messages
    chrome.runtime.onMessage.addListener(handleMessage);
  }

  async function handleToggleChange(event) {
    const enabled = event.target.checked;

    if (!currentTabId) {
      await getCurrentTab();
    }

    try {
      await chrome.runtime.sendMessage({
        type: 'SET_BLUR_MODE',
        tabId: currentTabId,
        enabled
      });

      updateToggleUI(enabled);
    } catch (e) {
      console.error('Failed to toggle blur mode:', e);
      elements.blurModeToggle.checked = !enabled;
    }
  }

  function updateToggleUI(enabled) {
    if (enabled) {
      elements.modeStatus.textContent = 'Active — click to blur';
      elements.modeStatus.classList.add('active');
      elements.activeIndicator.classList.remove('hidden');
    } else {
      elements.modeStatus.textContent = 'Click elements to blur';
      elements.modeStatus.classList.remove('active');
      elements.activeIndicator.classList.add('hidden');
    }
  }

  async function handleRunAutoBlur() {
    // Check if disclosure has been accepted
    if (!disclosureAccepted) {
      pendingAutoBlurRun = true;
      showDisclosureModal();
      return;
    }

    // Run auto-blur
    await executeAutoBlur();
  }

  async function executeAutoBlur() {
    if (!currentTabId) {
      await getCurrentTab();
    }

    const types = getSelectedAutoBlurTypes();

    if (types.length === 0) {
      showAutoBlurResult('Please select at least one type to detect.', 'error');
      return;
    }

    // Disable button during scan
    elements.runAutoBlurBtn.disabled = true;
    elements.runAutoBlurBtn.textContent = 'Scanning...';
    hideAutoBlurResult();

    try {
      const response = await chrome.tabs.sendMessage(currentTabId, {
        type: 'AUTO_BLUR_RUN',
        types
      });

      if (response && typeof response.blurredCount === 'number') {
        if (response.blurredCount > 0) {
          showAutoBlurResult(`Auto-blurred ${response.blurredCount} item${response.blurredCount !== 1 ? 's' : ''}.`, 'success');
        } else {
          showAutoBlurResult('No sensitive patterns found on this page.', 'info');
        }
        await updateBlurCount();
      } else {
        showAutoBlurResult('Could not scan this page.', 'error');
      }
    } catch (e) {
      console.error('Failed to run auto-blur:', e);
      showAutoBlurResult('Could not scan this page. Try refreshing.', 'error');
    } finally {
      elements.runAutoBlurBtn.disabled = false;
      elements.runAutoBlurBtn.textContent = 'Run auto-blur now';
    }
  }

  function getSelectedAutoBlurTypes() {
    const types = [];
    if (elements.blurEmails.checked) types.push('email');
    if (elements.blurPhones.checked) types.push('phone');
    if (elements.blurCards.checked) types.push('creditCard');
    if (elements.blurSSN.checked) {
      types.push('ssn');
      types.push('personnummer');
    }
    return types;
  }

  function showAutoBlurResult(message, type) {
    elements.autoBlurResult.textContent = message;
    elements.autoBlurResult.className = `autoblur-result ${type}`;
    elements.autoBlurResult.classList.remove('hidden');
  }

  function hideAutoBlurResult() {
    elements.autoBlurResult.classList.add('hidden');
  }

  function showDisclosureModal() {
    elements.disclosureModal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }

  function hideDisclosureModal() {
    elements.disclosureModal.classList.add('hidden');
    document.body.style.overflow = '';
  }

  function handleModalCancel() {
    hideDisclosureModal();
    pendingAutoBlurRun = false;
  }

  async function handleModalAccept() {
    // Save acceptance to storage
    try {
      await chrome.storage.local.set({ autoBlurDisclosureAccepted: true });
      disclosureAccepted = true;
    } catch (e) {
      console.error('Failed to save disclosure acceptance:', e);
    }

    hideDisclosureModal();

    // If user was trying to run auto-blur, execute it now
    if (pendingAutoBlurRun) {
      pendingAutoBlurRun = false;
      await executeAutoBlur();
    }
  }

  function handleClearClick() {
    elements.clearAllBtn.classList.add('hidden');
    elements.confirmClearBtn.classList.remove('hidden');

    if (confirmTimeout) {
      clearTimeout(confirmTimeout);
    }
    confirmTimeout = setTimeout(() => {
      elements.confirmClearBtn.classList.add('hidden');
      elements.clearAllBtn.classList.remove('hidden');
    }, 3000);
  }

  async function handleConfirmClear() {
    if (confirmTimeout) {
      clearTimeout(confirmTimeout);
    }

    try {
      await chrome.runtime.sendMessage({
        type: 'CLEAR_ALL_BLURS',
        url: currentUrl,
        tabId: currentTabId
      });

      updateBlurCountUI(0);

      elements.confirmClearBtn.classList.add('hidden');
      elements.clearAllBtn.classList.remove('hidden');

      hideAutoBlurResult();
    } catch (e) {
      console.error('Failed to clear blurs:', e);
    }
  }

  async function handleTabChange(activeInfo) {
    currentTabId = activeInfo.tabId;
    const tab = await chrome.tabs.get(currentTabId);
    currentUrl = tab.url;

    elements.blurModeToggle.checked = false;
    updateToggleUI(false);
    hideAutoBlurResult();

    await updateBlurCount();
  }

  async function handleTabUpdate(tabId, changeInfo, tab) {
    if (tabId === currentTabId && changeInfo.status === 'complete') {
      currentUrl = tab.url;

      elements.blurModeToggle.checked = false;
      updateToggleUI(false);
      hideAutoBlurResult();

      await updateBlurCount();
    }
  }

  function handleMessage(message, sender, sendResponse) {
    if (message.type === 'UPDATE_BLUR_COUNT') {
      updateBlurCountUI(message.count);
    }
    if (message.type === 'BLUR_MODE_TOGGLED') {
      elements.blurModeToggle.checked = message.enabled;
      updateToggleUI(message.enabled);
    }
    return true;
  }

  async function updateBlurCount() {
    if (!currentUrl) return;

    try {
      const response = await chrome.runtime.sendMessage({
        type: 'GET_BLUR_COUNT',
        url: currentUrl
      });

      if (response && typeof response.count === 'number') {
        updateBlurCountUI(response.count);
      }
    } catch (e) {
      console.error('Failed to get blur count:', e);
    }
  }

  function updateBlurCountUI(count) {
    elements.blurCount.textContent = count;

    if (count > 0) {
      elements.emptyState.classList.add('hidden');
      elements.hasBlursState.classList.remove('hidden');
      elements.clearAllBtn.disabled = false;
    } else {
      elements.emptyState.classList.remove('hidden');
      elements.hasBlursState.classList.add('hidden');
      elements.clearAllBtn.disabled = true;
    }

    elements.blurCount.style.transform = 'scale(1.2)';
    setTimeout(() => {
      elements.blurCount.style.transform = 'scale(1)';
    }, 150);
  }

  function startPolling() {
    setInterval(async () => {
      if (currentTabId && currentUrl) {
        try {
          const response = await chrome.tabs.sendMessage(currentTabId, {
            type: 'GET_BLUR_COUNT'
          });
          if (response && typeof response.count === 'number') {
            updateBlurCountUI(response.count);
          }
        } catch (e) {
          // Tab might not have content script
        }
      }
    }, 2000);
  }
})();
